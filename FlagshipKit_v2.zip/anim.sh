#!/system/bin/sh
SCALE=0.5
. /data/adb/flagship_kit/anim.conf 2>/dev/null
settings put global window_animation_scale "$SCALE"
settings put global transition_animation_scale "$SCALE"
settings put global animator_duration_scale "$SCALE"
