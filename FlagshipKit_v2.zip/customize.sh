SKIPUNZIP=0
D=/data/adb/flagship_kit
G=/data/adb/galaxyai_lite
ui_print "- Flagship Kit v2"
if [ -d /data/adb/modules/galaxyai_lite_a15 ]; then
  ui_print "! Old 'Galaxy AI Lite (A15)' module found."
  ui_print "! Remove it after this install (it is now built in)."
fi
mkdir -p $D $G
[ -f $D/apps.conf ] || : > $D/apps.conf
[ -f $D/user_presets.conf ] || : > $D/user_presets.conf
[ -f $D/global.conf ] || printf "GLOBAL=\nSKIP_SYSTEM=1\n" > $D/global.conf
[ -f $D/anim.conf ] || echo "SCALE=0.5" > $D/anim.conf
[ -f $G/config.conf ] || cp $MODPATH/galaxyai/defaults.conf $G/config.conf
grep -q 'GENAI_SUPPORT_OBJECT_ERASER' $G/config.conf || echo 'FFADD:SEC_FLOATING_FEATURE_GENAI_SUPPORT_OBJECT_ERASER=TRUE' >> $G/config.conf
grep -q 'LAUNCHER_CONFIG_ANIMATION_TYPE' $G/config.conf || echo 'FF:SEC_FLOATING_FEATURE_LAUNCHER_CONFIG_ANIMATION_TYPE=HighEnd' >> $G/config.conf
rm -f $G/disable $G/pending
set_perm_recursive $MODPATH 0 0 0755 0644
for f in service.sh daemon.sh anim.sh galaxyai/apply.sh galaxyai/apks.sh; do set_perm $MODPATH/$f 0 0 0755; done
if [ -f $MODPATH/zygisk/arm64-v8a.so ]; then ui_print "- Zygisk lib found (real Build.MODEL spoof)"; else ui_print "- No Zygisk lib: props-only spoof mode"; fi
ui_print "- Applying Galaxy AI Lite now..."
MODDIR=$MODPATH/galaxyai sh $MODPATH/galaxyai/apply.sh apply 2>&1 | while IFS= read -r l; do ui_print "  $l"; done
