#!/system/bin/sh
MODDIR=${0%/*}; D=/data/adb/flagship_kit
PID=$D/daemon.pid
[ -f $PID ] && kill -0 "$(cat $PID)" 2>/dev/null && exit 0
echo $$ > $PID
RP=resetprop; command -v resetprop >/dev/null 2>&1 || RP=/data/adb/ksu/bin/resetprop
KEYS="manufacturer brand model device name"
PFX=". system. vendor. odm. product. system_ext."
if [ ! -f $D/orig.conf ]; then
  for p in $PFX; do [ "$p" = "." ] && p=""
    for k in $KEYS; do echo "ro.product.$p$k=$(getprop ro.product.$p$k)"; done
  done > $D/orig.conf
fi
apply() { # manu brand model device name
  for p in $PFX; do [ "$p" = "." ] && p=""
    $RP ro.product.${p}manufacturer "$1"; $RP ro.product.${p}brand "$2"
    $RP ro.product.${p}model "$3"; $RP ro.product.${p}device "$4"; $RP ro.product.${p}name "$5"
  done
}
restore() { while IFS== read -r k v; do [ -n "$v" ] && $RP "$k" "$v"; done < $D/orig.conf; }
fg() { dumpsys activity activities 2>/dev/null | grep -m1 -E 'topResumedActivity|mResumedActivity' | sed -n 's/.* \([A-Za-z0-9_.]*\)\/.*/\1/p'; }
is_sys() { case "$1" in android|com.android.*|com.samsung.*|com.sec.*|com.sec) return 0;; esac; return 1; }
CUR=""; LAST=""
while true; do
  GLOBAL=""; SKIP_SYSTEM=1
  [ -f $D/global.conf ] && . $D/global.conf
  P=$(fg)
  if [ -n "$P" ]; then
    ID=$(grep -m1 "^$P|" $D/apps.conf | cut -d'|' -f2)
    if [ -z "$ID" ]; then
      if [ "$SKIP_SYSTEM" != 0 ] && is_sys "$P"; then ID=orig; else ID=$GLOBAL; fi
    fi
    KEY="$P:$ID:$GLOBAL"
    if [ "$KEY" != "$LAST" ]; then
      L=""; [ -n "$ID" ] && [ "$ID" != orig ] && L=$(grep -h -m1 "^$ID|" $MODDIR/presets.conf $D/user_presets.conf | head -n1)
      if [ -n "$L" ]; then
        apply "$(echo "$L"|cut -d'|' -f3)" "$(echo "$L"|cut -d'|' -f4)" "$(echo "$L"|cut -d'|' -f5)" "$(echo "$L"|cut -d'|' -f6)" "$(echo "$L"|cut -d'|' -f7)"
        echo "$P -> $ID" > $D/active
      elif [ -f $D/active ]; then restore; rm -f $D/active; fi
      LAST=$KEY
    fi
  fi
  sleep 2
done
