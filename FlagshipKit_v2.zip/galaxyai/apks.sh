#!/system/bin/sh
# Install / roll back the Samsung Gallery + Photo Editor APKs you downloaded.
#   sh apks.sh check      show installed vs file versions
#   sh apks.sh install    back up current, then install (update) both APKs
#   sh apks.sh rollback   remove the updates (back to the ROM's own version)
# Put the .apk files in /sdcard/Download (names from APKMirror are fine).
DL="${APK_DIR:-/sdcard/Download}"
BK=/sdcard/GalaxyAI_Lite_backup
PKGS="com.sec.android.gallery3d com.sec.android.mimage.photoretouching"
find_apk() { ls -t "$DL"/"$(printf '%s' "$1" | tr . _)"*.apk 2>/dev/null | head -n 1; }
inst_code() { dumpsys package "$1" 2>/dev/null | grep -m 1 -o 'versionCode=[0-9]*' | sed 's/versionCode=//'; }
inst_name() { dumpsys package "$1" 2>/dev/null | grep -m 1 'versionName=' | sed 's/.*versionName=//'; }
file_code() { printf '%s' "$1" | sed -n 's/.*-\([0-9]\{7,\}\)_minAPI.*/\1/p'; }
cmd="${1:-check}"
case "$cmd" in
  check)
    for p in $PKGS; do
      a=$(find_apk "$p")
      echo "$p"; echo "  installed: $(inst_name "$p") (code $(inst_code "$p"))"
      if [ -n "$a" ]; then echo "  file:      ${a##*/} (code $(file_code "$a"))"; else echo "  file:      NOT FOUND in $DL"; fi
    done ;;
  install)
    mkdir -p "$BK"
    for p in $PKGS; do
      a=$(find_apk "$p"); [ -n "$a" ] || { echo "! $p: apk not found in $DL"; continue; }
      ic=$(inst_code "$p"); fc=$(file_code "$a")
      echo "== $p  installed=$ic file=$fc"
      if [ -n "$ic" ] && [ -n "$fc" ] && [ "$fc" -lt "$ic" ]; then echo "! file is OLDER than installed, skipping (use rollback first if you really want it)"; continue; fi
      for f in $(pm path "$p" | sed 's/^package://'); do cp "$f" "$BK/${p}_${f##*/}" 2>/dev/null; done
      sz=$(wc -c < "$a")
      pm install -r -d -S "$sz" < "$a" 2>&1 | tail -n 3
      am force-stop "$p" >/dev/null 2>&1
      echo "   now: $(inst_name "$p") (code $(inst_code "$p"))"
    done
    echo "Done. Test: Gallery > open a photo > Edit > Object eraser." ;;
  rollback)
    for p in $PKGS; do echo "== $p"; pm uninstall-system-updates "$p" 2>&1 | tail -n 2; am force-stop "$p" >/dev/null 2>&1; done ;;
  *) echo "usage: apks.sh [check|install|rollback]" ;;
esac
