#!/system/bin/sh
# ---------------------------------------------------------------------------
# Galaxy AI Lite (A15) - core script
#
# Runtime-only: patches floating_feature.xml through a bind mount. There is no
# system/ overlay and no early-boot hook, so it also works with temporary /
# late-loaded root (LKM KernelSU) and cannot cause a bootloop by itself.
#
#   sh apply.sh apply            patch flags now (+ optional model spoof)
#   sh apply.sh boot             same, but waits for boot + safety guard
#   sh apply.sh revert           remove the bind mounts, restore model prop
#   sh apply.sh scan             write a diagnostic report to Download/
#   sh apply.sh status           show what is active
#   sh apply.sh set KEY=VALUE    SPOOF_MODEL / SPOOF_NAME / AUTO_FLAGS / RESTART_APPS
# ---------------------------------------------------------------------------

case "$0" in */*) _d="${0%/*}" ;; *) _d="." ;; esac
[ -n "$MODDIR" ] || MODDIR=$(cd "$_d" 2>/dev/null && pwd)
SELF="$MODDIR/apply.sh"
DATA="${GAL_DATA:-/data/adb/galaxyai_lite}"
CONF="$DATA/config.conf"
LOG="$DATA/log.txt"
REPORT_DIR="${GAL_REPORT_DIR:-/sdcard/Download}"
DRY="$GAL_DRY"            # test mode: no mount / chcon / resetprop / am
MODE="${1:-apply}"
mkdir -p "$DATA" 2>/dev/null

# Run inside init's mount namespace so the bind mount is visible to apps.
if [ -z "$GAL_NS" ] && [ -z "$DRY" ] && command -v nsenter >/dev/null 2>&1 &&
   nsenter --mount=/proc/1/ns/mnt -- /system/bin/true >/dev/null 2>&1; then
  GAL_NS=1; export GAL_NS MODDIR
  exec nsenter --mount=/proc/1/ns/mnt -- /system/bin/sh "$SELF" "$@"
fi

sz=0; [ -f "$LOG" ] && sz=$(wc -c < "$LOG"); sz=$((sz + 0))
if [ "$sz" -gt 200000 ]; then
  tail -n 300 "$LOG" > "$LOG.tmp" 2>/dev/null && mv "$LOG.tmp" "$LOG"
fi

CR=$(printf '\r')
TAB=$(printf '\t')
APPS="com.sec.android.app.launcher com.android.settings com.samsung.android.app.notes com.sec.android.gallery3d com.sec.android.mimage.photoretouching com.samsung.android.honeyboard com.sec.android.app.sbrowser com.sec.android.app.voicenote com.samsung.android.dialer com.samsung.android.messaging"
AI_RE='_AI_|_AI>|NATIVE_AI|GALAXY_AI|GENERATIV|INTELLIGEN|GAUSS|_NPU|LLM|SUMMAR|TRANSLAT|TRANSCRIPT|SEMANTIC|ASSIST|ERASER|REMASTER|SKETCH'

log() { printf '%s %s\n' "$(date '+%m-%d %H:%M:%S' 2>/dev/null)" "$*" >> "$LOG" 2>/dev/null; }
say() { printf '%s\n' "$*"; log "$*"; }

# ---------------------------------------------------------------- helpers ---
trim() {
  T=$1
  T=${T%"$CR"}
  while :; do case "$T" in ' '*|"$TAB"*) T=${T#?} ;; *) break ;; esac; done
  while :; do case "$T" in *' '|*"$TAB") T=${T%?} ;; *) break ;; esac; done
}
valid_tag() { case "$1" in ''|*[!A-Z0-9_]*) return 1 ;; esac; return 0; }
valid_val() { case "$1" in ''|*[!A-Za-z0-9_.,:=/+\ -]*) return 1 ;; esac; return 0; }
key_of() { printf '%s' "$1" | tr '/' '_' | sed 's/^_//; s/\.xml$//'; }
get_ctx() {
  ls -Z "$1" 2>/dev/null | grep -o 'u:object_r:[A-Za-z0-9_]*:s[0-9][A-Za-z0-9,:._]*' | head -n 1
}

find_ff_files() {
  _seen=" "
  for _c in ${GAL_FF_CANDIDATES:-/vendor/etc/floating_feature.xml /system/etc/floating_feature.xml /odm/etc/floating_feature.xml}; do
    [ -f "$_c" ] || continue
    _r=$(readlink -f "$_c" 2>/dev/null); [ -n "$_r" ] || _r=$_c
    case "$_seen" in *" $_r "*) continue ;; esac
    _seen="$_seen$_r "
    printf '%s\n' "$_r"
  done
}

# is the top-most mount on $1 one of ours?
is_our_mount() {
  [ -z "$DRY" ] || return 1
  grep -F " $1 " /proc/self/mountinfo 2>/dev/null | tail -n 1 | grep -q "galaxyai_lite"
}
unmount_ours() {
  [ -z "$DRY" ] || return 0
  _n=0
  while is_our_mount "$1" && [ "$_n" -lt 8 ]; do
    umount "$1" 2>/dev/null || umount -l "$1" 2>/dev/null || break
    _n=$((_n + 1))
  done
  return 0
}
do_mount() {
  if [ -n "$DRY" ]; then say "  [dry] bind $1 -> $2"; return 0; fi
  mount -o bind "$1" "$2"
}
do_chcon() { [ -n "$DRY" ] && return 0; chcon "$1" "$2" 2>/dev/null; }
verify_mount() { # real patched ctx
  [ -n "$DRY" ] && return 0
  cmp -s "$1" "$2" || return 1
  _now=$(get_ctx "$1")
  [ -z "$3" ] || [ "$_now" = "$3" ] || return 1
  return 0
}

# ---------------------------------------------------------- xml patching ----
ff_get() { sed -n "s#.*<$2>\([^<]*\)</$2>.*#\1#p" "$1" | head -n 1; }
# ff_set FILE TAG VALUE -> 0 changed, 1 tag absent, 2 already that value
ff_set() {
  grep -q "<$2>[^<]*</$2>" "$1" 2>/dev/null || return 1
  [ "$(ff_get "$1" "$2")" = "$3" ] && return 2
  sed -i "s#<$2>[^<]*</$2>#<$2>$3</$2>#" "$1" || return 1
  return 0
}
# insert the lines of ADDFILE right before the closing root tag
ff_insert() {
  _o="$1.ins"; _done=0; : > "$_o" || return 1
  while IFS= read -r _l || [ -n "$_l" ]; do
    if [ "$_done" = 0 ]; then
      case "$_l" in *'</SecFloatingFeatureSet>'*) cat "$2" >> "$_o"; _done=1 ;; esac
    fi
    printf '%s\n' "$_l" >> "$_o"
  done < "$1"
  if [ "$_done" = 1 ]; then mv "$_o" "$1"; else rm -f "$_o"; return 1; fi
}
# ff_sane ORIG PATCHED
ff_sane() {
  [ -s "$2" ] || return 1
  grep -q '<SecFloatingFeatureSet>' "$2" || return 1
  [ "$(grep -c '</SecFloatingFeatureSet>' "$2")" = 1 ] || return 1
  _os=$(wc -c < "$1"); _ps=$(wc -c < "$2")
  _os=$((_os + 0)); _ps=$((_ps + 0))
  [ "$_ps" -ge $((_os - 64)) ] || return 1
  [ "$_ps" -le $((_os + 4096)) ] || return 1
  _oe=$(grep -c '</SEC_FLOATING_FEATURE' "$1"); _pe=$(grep -c '</SEC_FLOATING_FEATURE' "$2")
  [ "$_pe" -ge "$_oe" ] || return 1
  return 0
}

# ----------------------------------------------------------------- config ---
load_conf() {
  SPOOF_MODEL=0; SPOOF_NAME="SM-S938B"; RESTART_APPS=1; AUTO_FLAGS=1
  FF_SET_FILE="$DATA/.ff_set"; FF_ADD_FILE="$DATA/.ff_add"
  : > "$FF_SET_FILE"; : > "$FF_ADD_FILE"
  [ -f "$CONF" ] || return 0
  while IFS= read -r _raw || [ -n "$_raw" ]; do
    trim "$_raw"; _line=$T
    case "$_line" in *' #'*) _line=${_line%% '#'*}; trim "$_line"; _line=$T ;; esac
    case "$_line" in
      ''|'#'*) continue ;;
      SPOOF_MODEL=*)   _v=${_line#*=}; case "$_v" in 0|1) SPOOF_MODEL=$_v ;; esac ;;
      RESTART_APPS=*)  _v=${_line#*=}; case "$_v" in 0|1) RESTART_APPS=$_v ;; esac ;;
      AUTO_FLAGS=*)    _v=${_line#*=}; case "$_v" in 0|1) AUTO_FLAGS=$_v ;; esac ;;
      SPOOF_NAME=*)    _v=${_line#*=}; case "$_v" in ''|*[!A-Za-z0-9-]*) ;; *) SPOOF_NAME=$_v ;; esac ;;
      FF:*|FFADD:*)
        _kind=${_line%%:*}; _rest=${_line#*:}
        _tag=${_rest%%=*}; _val=${_rest#*=}
        if [ "$_rest" != "$_tag" ] && valid_tag "$_tag" && valid_val "$_val"; then
          if [ "$_kind" = FF ]; then printf '%s=%s\n' "$_tag" "$_val" >> "$FF_SET_FILE"
          else printf '%s=%s\n' "$_tag" "$_val" >> "$FF_ADD_FILE"; fi
        else
          log "config: ignored invalid line: $_line"
        fi ;;
      *) log "config: ignored unknown line: $_line" ;;
    esac
  done < "$CONF"
}

cmd_set() { # KEY=VALUE
  _k=${1%%=*}; _v=${1#*=}
  if [ -z "$1" ] || [ "$_k" = "$1" ]; then echo "usage: apply.sh set KEY=VALUE"; return 1; fi
  case "$_k" in
    SPOOF_MODEL|RESTART_APPS|AUTO_FLAGS) case "$_v" in 0|1) ;; *) echo "value must be 0 or 1"; return 1 ;; esac ;;
    SPOOF_NAME) case "$_v" in ''|*[!A-Za-z0-9-]*) echo "bad model name"; return 1 ;; esac ;;
    *) echo "unknown key: $_k"; return 1 ;;
  esac
  [ -f "$CONF" ] || cp "$MODDIR/defaults.conf" "$CONF"
  if grep -q "^$_k=" "$CONF"; then sed -i "s#^$_k=.*#$_k=$_v#" "$CONF"; else printf '%s=%s\n' "$_k" "$_v" >> "$CONF"; fi
  echo "ok: $_k=$_v  (tap Action / run apply to use it)"
}

# ------------------------------------------------------------ flag logic ----
# patch_flags WORKFILE   (sets NCHG; returns 1 on hard failure)
patch_flags() {
  _f="$1"
  # 1) explicit FF: lines (only if the tag exists)
  while IFS= read -r _kv; do
    [ -n "$_kv" ] || continue
    _t=${_kv%%=*}; _v=${_kv#*=}
    ff_set "$_f" "$_t" "$_v"; _rc=$?
    case $_rc in
      0) say "    set $_t=$_v"; NCHG=$((NCHG + 1)) ;;
      1) log "    (absent in this ROM) $_t" ;;
    esac
  done < "$FF_SET_FILE"

  # 2) AUTO: tags that clearly say NATIVE_AI / GALAXY_AI / GENERATIVE_AI
  if [ "$AUTO_FLAGS" = 1 ]; then
    grep -E '<SEC_FLOATING_FEATURE_[A-Z0-9_]*(NATIVE_AI|GALAXY_AI|GENERATIVE_AI)[A-Z0-9_]*>' "$_f" > "$DATA/.cand" 2>/dev/null
    while IFS= read -r _l; do
      _t=$(printf '%s' "$_l" | sed -n 's#.*<\(SEC_FLOATING_FEATURE_[A-Z0-9_]*\)>[^<]*</.*#\1#p')
      _v=$(printf '%s' "$_l" | sed -n 's#.*<SEC_FLOATING_FEATURE_[A-Z0-9_]*>\([^<]*\)</.*#\1#p')
      [ -n "$_t" ] || continue
      case "$_v" in TRUE|FALSE) ;; *) continue ;; esac
      case "$_t" in
        *DISABLE*)          _want=FALSE ;;
        *SUPPORT*|*ENABLE*) _want=TRUE ;;
        *) continue ;;
      esac
      [ "$_v" = "$_want" ] && continue
      if ff_set "$_f" "$_t" "$_want"; then say "    auto $_t: $_v -> $_want"; NCHG=$((NCHG + 1)); fi
    done < "$DATA/.cand"
  fi

  # 3) FFADD: change or add
  : > "$DATA/.add_lines"
  while IFS= read -r _kv; do
    [ -n "$_kv" ] || continue
    _t=${_kv%%=*}; _v=${_kv#*=}
    ff_set "$_f" "$_t" "$_v"; _rc=$?
    case $_rc in
      0) say "    set $_t=$_v"; NCHG=$((NCHG + 1)) ;;
      1) printf '    <%s>%s</%s>\n' "$_t" "$_v" "$_t" >> "$DATA/.add_lines"
         say "    add $_t=$_v"; NCHG=$((NCHG + 1)) ;;
    esac
  done < "$FF_ADD_FILE"
  if [ -s "$DATA/.add_lines" ]; then ff_insert "$_f" "$DATA/.add_lines" || return 1; fi
  return 0
}

process_file() {
  real="$1"; key=$(key_of "$real")
  mkdir -p "$DATA/orig" "$DATA/ff" 2>/dev/null
  orig="$DATA/orig/$key.xml"; pat="$DATA/ff/$key.xml"; work="$DATA/ff/$key.work"

  unmount_ours "$real"     # reveal the stock file again
  if is_our_mount "$real"; then
    say "! could not remove previous patch on $real - using saved stock copy"
    [ -s "$orig" ] || return 1
  else
    cat "$real" > "$orig.tmp" 2>/dev/null && [ -s "$orig.tmp" ] || { rm -f "$orig.tmp"; say "! cannot read $real"; return 1; }
    mv "$orig.tmp" "$orig"
  fi
  grep -q '<SecFloatingFeatureSet>' "$orig" || { say "- skip $real (unexpected format)"; return 1; }

  ctx=$(get_ctx "$real"); [ -n "$ctx" ] || ctx="u:object_r:system_file:s0"
  cp "$orig" "$work" || return 1
  NCHG=0
  if ! patch_flags "$work"; then say "! $real: could not edit file, NOT applied"; rm -f "$work"; return 1; fi
  if [ "$NCHG" -eq 0 ]; then
    say "- $real: no Galaxy AI flag to change"
    rm -f "$work"; return 0
  fi
  if ! ff_sane "$orig" "$work"; then say "! $real: sanity check failed, NOT applied"; rm -f "$work"; return 1; fi

  mv "$work" "$pat"; chmod 644 "$pat"; chown 0:0 "$pat" 2>/dev/null; do_chcon "$ctx" "$pat"
  if do_mount "$pat" "$real" && verify_mount "$real" "$pat" "$ctx"; then
    say "+ $real patched ($NCHG flag(s))"
    MOUNTED=$((MOUNTED + 1)); TOTAL_CHG=$((TOTAL_CHG + NCHG))
  else
    say "! $real: mount/verify failed (SELinux?) - rolled back"
    unmount_ours "$real"; return 1
  fi
  return 0
}

# ------------------------------------------------------------ model spoof ---
find_rp() {
  command -v resetprop 2>/dev/null && return 0
  for _p in /data/adb/ksu/bin/resetprop /data/adb/magisk/resetprop /data/adb/ap/bin/resetprop; do
    [ -x "$_p" ] && { printf '%s\n' "$_p"; return 0; }
  done
  return 1
}
set_model() { # name
  _rp=$(find_rp) || return 1
  for _p in ro.product.model ro.product.system.model ro.product.product.model; do
    "$_rp" -n "$_p" "$1" >/dev/null 2>&1
  done
}
do_spoof() {
  [ "$SPOOF_MODEL" = 1 ] || return 0
  if [ -n "$DRY" ]; then say "[dry] spoof model -> $SPOOF_NAME"; return 0; fi
  find_rp >/dev/null || { say "! model spoof skipped: resetprop not found"; return 1; }
  _cur=$(getprop ro.product.model)
  [ -s "$DATA/orig_model" ] || printf '%s\n' "$_cur" > "$DATA/orig_model"
  if [ "$_cur" = "$SPOOF_NAME" ]; then say "= model already $SPOOF_NAME"; return 0; fi
  set_model "$SPOOF_NAME"
  say "+ model spoof: $_cur -> $(getprop ro.product.model)"
}
restart_apps() {
  [ "$RESTART_APPS" = 1 ] || return 0
  if [ -n "$DRY" ]; then say "[dry] force-stop apps"; return 0; fi
  _extra=$(pm list packages 2>/dev/null | sed 's/^package://' | grep -E '^com\.(samsung|sec)\..*(intelligence|galaxyai|gauss|generativ|aiassist)')
  for _p in $APPS $_extra; do am force-stop "$_p" >/dev/null 2>&1; done
  say "- apps restarted so they re-read the flags"
}

# --------------------------------------------------------------- commands ---
cmd_apply() {
  load_conf
  _files=$(find_ff_files)
  [ -n "$_files" ] || { say "! no floating_feature.xml found - is this a Samsung ROM?"; return 1; }
  MOUNTED=0; TOTAL_CHG=0
  for _f in $_files; do process_file "$_f"; done
  do_spoof
  if [ "$MOUNTED" -gt 0 ] || [ "$SPOOF_MODEL" = 1 ]; then restart_apps; fi
  say "== done: files patched=$MOUNTED, flags changed=$TOTAL_CHG, model spoof=$SPOOF_MODEL"
  if [ "$MOUNTED" -eq 0 ]; then
    say "   Nothing was patched: this firmware has no *_NATIVE_AI / GALAXY_AI flag."
    say "   Send me the report (Download/GalaxyAI_Lite_report.txt) and I will pick the right flags."
  else
    say "   Open Settings and search 'Galaxy AI'; also check Notes, Keyboard, Gallery."
    say "   System-level parts need a framework restart (soft reboot); apps are already refreshed."
  fi
  return 0
}

cmd_boot() {
  [ -f "$DATA/disable" ] && { log "boot: disabled by $DATA/disable"; return 0; }
  if [ -f "$DATA/pending" ]; then
    : > "$DATA/disable"; rm -f "$DATA/pending"
    log "boot: previous run did not finish cleanly -> auto-disabled (delete $DATA/disable to re-enable)"
    return 0
  fi
  _n=0
  while [ "$(getprop sys.boot_completed)" != 1 ] && [ "$_n" -lt 120 ]; do sleep 3; _n=$((_n + 1)); done
  sleep 25
  : > "$DATA/pending"
  _sp=$(pidof system_server)
  cmd_apply >/dev/null 2>&1
  ( sleep 120
    if [ "$(getprop sys.boot_completed)" = 1 ] && [ "$(pidof system_server)" = "$_sp" ]; then rm -f "$DATA/pending"; fi
  ) >/dev/null 2>&1 &
}

cmd_revert() {
  load_conf
  for _f in $(find_ff_files); do
    if is_our_mount "$_f"; then unmount_ours "$_f"; say "- patch removed from $_f"; fi
  done
  if [ -s "$DATA/orig_model" ] && [ -z "$DRY" ] && find_rp >/dev/null; then
    _m=$(cat "$DATA/orig_model"); set_model "$_m"; say "- model restored: $_m"
  fi
  restart_apps
  say "== reverted (a normal reboot also returns everything to stock)"
}

cmd_status() {
  load_conf
  printf 'config: SPOOF_MODEL=%s (%s) AUTO_FLAGS=%s RESTART_APPS=%s\n' "$SPOOF_MODEL" "$SPOOF_NAME" "$AUTO_FLAGS" "$RESTART_APPS"
  for _f in $(find_ff_files); do
    if is_our_mount "$_f"; then printf 'ACTIVE    %s\n' "$_f"; else printf 'inactive  %s\n' "$_f"; fi
  done
  printf 'model now: %s\n' "$(getprop ro.product.model)"
  [ -f "$DATA/disable" ] && printf 'boot auto-run is DISABLED (delete %s)\n' "$DATA/disable"
  echo "--- last log lines ---"; tail -n 15 "$LOG" 2>/dev/null
}

cmd_scan() {
  mkdir -p "$REPORT_DIR" 2>/dev/null
  _out="$REPORT_DIR/GalaxyAI_Lite_report.txt"
  _rm=$(cat "$DATA/orig_model" 2>/dev/null); [ -n "$_rm" ] || _rm=$(getprop ro.product.model)
  {
    echo "== Galaxy AI Lite report =="
    echo "date: $(date 2>/dev/null)"
    echo "model now: $(getprop ro.product.model)   real: $_rm"
    echo "device: $(getprop ro.product.device)   soc: $(getprop ro.soc.model) $(getprop ro.board.platform)"
    echo "build: $(getprop ro.build.display.id)"
    echo "oneui: $(getprop ro.build.version.oneui)  sem: $(getprop ro.build.version.sem)  android: $(getprop ro.build.version.release) (sdk $(getprop ro.build.version.sdk))"
    echo "csc: $(getprop ro.csc.sales_code) $(getprop ro.csc.country_code)"
    echo "kernel: $(uname -r 2>/dev/null)"
    echo
    for _f in $(find_ff_files); do
      _k=$(key_of "$_f")
      if is_our_mount "$_f" && [ -s "$DATA/orig/$_k.xml" ]; then _src="$DATA/orig/$_k.xml"; else _src="$_f"; fi
      echo "== $_f  (ctx=$(get_ctx "$_f") size=$(wc -c < "$_src" 2>/dev/null)) - STOCK values =="
      grep -E "<SEC_FLOATING_FEATURE_[A-Z0-9_]*($AI_RE)" "$_src" 2>/dev/null | sed 's/^[ 	]*//'
      echo "-- active patch: $(is_our_mount "$_f" && echo YES || echo no)"
      echo
      cp "$_src" "$REPORT_DIR/GalaxyAI_Lite_stock_$_k.xml" 2>/dev/null
    done
    echo "== Samsung packages that look AI-related =="
    pm list packages 2>/dev/null | sed 's/^package://' | grep -iE 'intelligen|galaxyai|gauss|generativ|photoassist|aiassist|interpreter|transcript|summar|writing|aimodelprovider|aicore|\.scs|vexfwk|saiv|photoremaster|visual|vision|objectremoval|aimediaenhancer' | sort
    echo
    echo "== key app versions =="
    for _p in com.samsung.android.honeyboard com.samsung.android.app.notes com.sec.android.gallery3d com.sec.android.mimage.photoretouching com.sec.android.app.sbrowser com.sec.android.app.voicenote com.samsung.android.dialer com.android.settings; do
      _v=$(dumpsys package "$_p" 2>/dev/null | grep -m 1 'versionName=' | sed 's/.*versionName=//')
      [ -n "$_v" ] && echo "$_p  $_v"
    done
    echo
    echo "== last log lines =="; tail -n 25 "$LOG" 2>/dev/null
  } > "$_out" 2>/dev/null
  chmod 666 "$_out" "$REPORT_DIR"/GalaxyAI_Lite_stock_*.xml 2>/dev/null
  echo "report: $_out"
  echo "(full stock floating_feature copies: $REPORT_DIR/GalaxyAI_Lite_stock_*.xml)"
}

case "$MODE" in
  apply)  cmd_apply ;;
  boot)   cmd_boot ;;
  revert) cmd_revert ;;
  scan)   cmd_scan ;;
  status) cmd_status ;;
  set)    cmd_set "$2" ;;
  *)      echo "usage: apply.sh [apply|boot|revert|scan|status|set KEY=VALUE]" ;;
esac
