#!/system/bin/sh
MODDIR=${0%/*}
until [ "$(getprop sys.boot_completed)" = 1 ]; do sleep 2; done
sleep 8
sh $MODDIR/anim.sh
nohup sh $MODDIR/daemon.sh >/dev/null 2>&1 &
sh $MODDIR/galaxyai/apply.sh boot >/dev/null 2>&1 &
