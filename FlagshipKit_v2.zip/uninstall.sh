#!/system/bin/sh
MODDIR=${0%/*}
sh $MODDIR/galaxyai/apply.sh revert >/dev/null 2>&1
[ -f /data/adb/flagship_kit/daemon.pid ] && kill "$(cat /data/adb/flagship_kit/daemon.pid)" 2>/dev/null
rm -rf /data/adb/flagship_kit /data/adb/galaxyai_lite
