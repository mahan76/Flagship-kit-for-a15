cmake_minimum_required(VERSION 3.18)
project(flagship_kit)
set(CMAKE_CXX_STANDARD 17)
add_library(flagship_kit SHARED main.cpp)
target_link_libraries(flagship_kit log)
# Output: rename libflagship_kit.so -> module/zygisk/arm64-v8a.so
