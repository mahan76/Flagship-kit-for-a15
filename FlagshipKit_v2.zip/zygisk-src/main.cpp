// Needs zygisk.hpp (Zygisk API, from Magisk/ZygiskNext repo) next to this file. Build with Android NDK (arm64-v8a).
#include <jni.h>
#include <unistd.h>
#include <cstdint>
#include <string>
#include <fstream>
#include <vector>
#include "zygisk.hpp"
using zygisk::Api; using zygisk::AppSpecializeArgs; using zygisk::ServerSpecializeArgs;
#define D "/data/adb/flagship_kit"

static std::vector<std::string> split(const std::string& s, char c) {
  std::vector<std::string> o; std::string t;
  for (char x : s) { if (x == c) { o.push_back(t); t.clear(); } else t += x; }
  o.push_back(t); return o;
}
static std::string findLine(const char* file, const std::string& key) {
  std::ifstream f(file); std::string l;
  while (std::getline(f, l)) if (l.rfind(key + "|", 0) == 0) return l;
  return "";
}
static std::string getConf(const char* key) {
  std::ifstream f(D "/global.conf"); std::string l, k = std::string(key) + "=";
  while (std::getline(f, l)) if (l.rfind(k, 0) == 0) return l.substr(k.size());
  return "";
}
static bool isSys(const std::string& p) {
  return p == "android" || p == "com.sec" || p.rfind("com.android.", 0) == 0 ||
         p.rfind("com.samsung.", 0) == 0 || p.rfind("com.sec.", 0) == 0;
}
static void companion(int fd) {
  uint32_t n = 0; std::string pkg, out;
  if (read(fd, &n, 4) == 4 && n > 0 && n < 256) {
    pkg.resize(n); read(fd, &pkg[0], n);
    std::string id; auto a = split(findLine(D "/apps.conf", pkg), '|');
    if (a.size() >= 2) id = a[1];
    if (id.empty()) {
      if (getConf("SKIP_SYSTEM") != "0" && isSys(pkg)) id = "";
      else id = getConf("GLOBAL");
    }
    if (!id.empty() && id != "orig") {
      std::string p = findLine("/data/adb/modules/flagship_kit/presets.conf", id);
      if (p.empty()) p = findLine(D "/user_presets.conf", id);
      auto v = split(p, '|');
      if (v.size() >= 7) out = v[2] + "|" + v[3] + "|" + v[4] + "|" + v[5] + "|" + v[6];
    }
  }
  uint32_t rl = out.size(); write(fd, &rl, 4); if (rl) write(fd, out.data(), rl);
}
static void setStr(JNIEnv* e, jclass c, const char* f, const std::string& v) {
  jfieldID id = e->GetStaticFieldID(c, f, "Ljava/lang/String;");
  if (!id) { e->ExceptionClear(); return; }
  e->SetStaticObjectField(c, id, e->NewStringUTF(v.c_str()));
}
class Spoof : public zygisk::ModuleBase {
  Api* api; JNIEnv* env; std::string res;
  void onLoad(Api* a, JNIEnv* e) override { api = a; env = e; }
  void preAppSpecialize(AppSpecializeArgs* args) override {
    if (!args->nice_name) return;
    const char* n = env->GetStringUTFChars(args->nice_name, nullptr);
    std::string pkg = n; env->ReleaseStringUTFChars(args->nice_name, n);
    pkg = pkg.substr(0, pkg.find(':'));
    int fd = api->connectCompanion();
    if (fd >= 0) {
      uint32_t l = pkg.size(), rl = 0;
      write(fd, &l, 4); write(fd, pkg.data(), l);
      if (read(fd, &rl, 4) == 4 && rl > 0 && rl < 512) { res.resize(rl); read(fd, &res[0], rl); }
      close(fd);
    }
    if (res.empty()) api->setOption(zygisk::Option::DLCLOSE_MODULE_LIBRARY);
  }
  void postAppSpecialize(const AppSpecializeArgs*) override {
    if (res.empty()) return;
    auto v = split(res, '|'); if (v.size() < 5) return;
    jclass b = env->FindClass("android/os/Build"); if (!b) { env->ExceptionClear(); return; }
    setStr(env, b, "MANUFACTURER", v[0]); setStr(env, b, "BRAND", v[1]);
    setStr(env, b, "MODEL", v[2]); setStr(env, b, "DEVICE", v[3]); setStr(env, b, "PRODUCT", v[4]);
  }
};
REGISTER_ZYGISK_MODULE(Spoof)
REGISTER_ZYGISK_COMPANION(companion)
